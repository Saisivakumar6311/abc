package protected2;


import sl_assisted_project2.*;

public class protect extends protectedaccessspecifiers {

	public static void main(String[] args) {
		protect obj = new protect ();   
	       obj.display();  
	}

}
