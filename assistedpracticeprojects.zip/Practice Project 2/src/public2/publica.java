package public2;


import sl_assisted_project2.*;

public class publica extends publicaccessspecifier {

	public static void main(String[] args) {
		publicaccessspecifier obj = new publicaccessspecifier ();   
	       obj.display();  
	}

}
